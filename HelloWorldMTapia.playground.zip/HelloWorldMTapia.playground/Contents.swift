import UIKit
// Testing stuff with images and graphs
var greeting = "Hello, playground"
var image = UIImage(named: "Swift.png")

var j = 1
for i in 1...5{
    j += i
}
// Learning how to use print correctly
print("Hello world!")

var name = "Michael Tapia"
var language = "Swift"

var mes1 = "\(name), Welcome to the wonderful world of \(language)!"

var mes2 = " Welcome to the wonderful world of"

print(mes1)
print(name, mes2, language)

// The to: parameter

var name1 = "Jake"
var name2 = "Karen"
var name3 = "John"
var name4 = "Kara"

var line = ""

print(name1, name2, name3, name4, separator:", ", terminator:"", to:&line)

print(line)
