import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
            Button("Calculate Me!"){
                calculate()
            }
        }
    }
}

func calculate() {
    var possibility = 15
    possibility += 5
    possibility *= 4
    possibility -= 10
    possibility /= 1
    print(possibility)
}

