import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            var x = 0

            let coin = 15
            let redCoin = 10
            let greenCoin = 30
            Button("Regular Coin") {
                x += coin
                print(x, "\nYou gained 15 points!")
                
            }
            Button("Red Coin") {
                x -= redCoin
                print(x, "\nYou just lost 10 points! Yikes!")
            }
            Button("Green Coin") {
                x += greenCoin
                print(x, "\nYou gained 30 points!")
            }
        }
    }
}

