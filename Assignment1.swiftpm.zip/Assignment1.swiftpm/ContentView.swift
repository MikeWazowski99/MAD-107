import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!\n")
            Text("This is me just testing and messing around with stuff\n")
                .multilineTextAlignment(.center)
            Text("Get as many points as possible!\n")
            
        }
    }
}
